import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(rootDir, 'app.js'), 'utf8');
const mainJs = fs.readFileSync(path.join(rootDir, 'main.js'), 'utf8');

// Extract pure functions directly from index.html to test production code
function extractFn(source, name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `Function ${name} not found in index.html`);
  let depth = 0;
  let inBrace = false;
  for (let i = start; i < source.length; i++) {
    if (source[i] === '{') { depth++; inBrace = true; }
    else if (source[i] === '}') {
      depth--;
      if (inBrace && depth === 0) return source.slice(start, i + 1);
    }
  }
  throw new Error(`Unclosed function ${name}`);
}

const sandbox = {
  state: { referenceDate: '2026-11-19', groupBy: 'NONE', sortField: 'dueDate', sortAsc: true, searchQuery: '', supplierFilter: 'ALL', statusFilter: 'ALL', records: [] },
  currentUrgencyMap: new Map()
};

const fnNames = [
  'calcMod10', 'calcMod11Boleto', 'calcMod11Arrecadacao', 'validateDigitableLine',
  'isValidCnpj', 'isValidCpf', 'normalizePixKey',
  'isValidIsoDate', 'getDaysDifference', 'classifyRecordUrgency',
  'getRecordUrgency', 'getFilteredAndSortedRecords'
];
const bundle = fnNames.map(n => extractFn(html, n)).join('\n\n');
vm.runInNewContext(bundle, sandbox);

// ---------------------------------------------------------
// 1. TESTES DE LINHA DIGITÁVEL (3 VÁLIDAS + 3 INVÁLIDAS)
// ---------------------------------------------------------
// Helper to build a mathematically valid 47-digit FEBRABAN bank boleto line from a 43-digit barcode body
function makeValidBoleto47(bank3, currency1, factor4, value10, free25) {
  const body43 = bank3 + currency1 + factor4 + value10 + free25;
  const dvGeneral = sandbox.calcMod11Boleto(body43);
  const c1 = bank3 + currency1 + free25.slice(0, 5);
  const c2 = free25.slice(5, 15);
  const c3 = free25.slice(15, 25);
  return `${c1}${sandbox.calcMod10(c1)}${c2}${sandbox.calcMod10(c2)}${c3}${sandbox.calcMod10(c3)}${dvGeneral}${factor4}${value10}`;
}

// Helper to build a mathematically valid 48-digit FEBRABAN arrecadação line
function makeValidArrecadacao48(idValor, body40) {
  // barcode44 = '8' + '2' + idValor + dvGeneral + body40
  const calc = (idValor === '6' || idValor === '7') ? sandbox.calcMod10 : sandbox.calcMod11Arrecadacao;
  const withoutDv = '82' + idValor + body40;
  const dvGeneral = calc(withoutDv);
  const full44 = '82' + idValor + String(dvGeneral) + body40;
  let out = '';
  for (let i = 0; i < 4; i++) {
    const blk = full44.slice(i * 11, (i + 1) * 11);
    out += blk + String(calc(blk));
  }
  return out;
}

const validLines = [
  // 1) Boleto Itaú (341) 47 dígitos válido
  makeValidBoleto47('341', '9', '9904', '0000248050', '1790010104351004791020150'),
  // 2) Boleto Bradesco (237) 47 dígitos válido
  makeValidBoleto47('237', '9', '9906', '0000419000', '3381260083013528560000633'),
  // 3) Guia de Arrecadação (48 dígitos, identificador '6' -> módulo 10) válida
  makeValidArrecadacao48('6', '0000001500000001234567890123456789012345')
];

const invalidLines = [
  // 1) 47 dígitos com DV geral alterado
  validLines[0].slice(0, 32) + String((Number(validLines[0][32]) + 1) % 10) + validLines[0].slice(33),
  // 2) 47 dígitos com DV do campo 1 alterado
  validLines[1].slice(0, 9) + String((Number(validLines[1][9]) + 1) % 10) + validLines[1].slice(10),
  // 3) Tamanho inválido (apenas 20 dígitos)
  '34191790010104351004'
];

for (const line of validLines) {
  const res = sandbox.validateDigitableLine(line);
  assert.equal(res.valid, true, `Esperava válida: ${line}, obteve ${JSON.stringify(res)}`);
  assert.equal(res.label, 'dígitos ok');
}
assert.equal(sandbox.validateDigitableLine(invalidLines[0]).valid, false);
assert.equal(sandbox.validateDigitableLine(invalidLines[0]).label, 'dígito verificador inválido');
assert.equal(sandbox.validateDigitableLine(invalidLines[1]).valid, false);
assert.equal(sandbox.validateDigitableLine(invalidLines[1]).label, 'dígito verificador inválido');
assert.equal(sandbox.validateDigitableLine(invalidLines[2]).valid, false);
assert.equal(sandbox.validateDigitableLine(invalidLines[2]).label, 'confira os dígitos');
console.log('PASS [1/5] Validação de linha digitável (3 válidas + 3 inválidas)');

// ---------------------------------------------------------
// 2. TESTES DE NORMALIZAÇÃO DE CHAVE PIX
// ---------------------------------------------------------
assert.equal(sandbox.normalizePixKey('43.283.811/0001-50'), '43283811000150');
assert.equal(sandbox.normalizePixKey('(16) 99123-4567'), '+5516991234567');
assert.equal(sandbox.normalizePixKey('Financeiro@Empresa.COM.BR'), 'financeiro@empresa.com.br');
const uuid = '550e8400-e29b-41d4-a716-446655440000';
assert.equal(sandbox.normalizePixKey(uuid), uuid);
console.log('PASS [2/5] Normalização de chave PIX (CNPJ, telefone, e-mail, UUID)');

// ---------------------------------------------------------
// 3. TESTE DE AGRUPAMENTO SEM CABEÇALHOS REPETIDOS
// ---------------------------------------------------------
sandbox.state.records = [
  { id: '1', supplier: 'Fornecedor B', dueDate: '2026-11-18', amountCents: 10000, status: 'PENDING', cnpj: '', nfeNumber: '', parcela: '', digitableLine: '', xmlFileName: '', boletoFileName: '' },
  { id: '2', supplier: 'Fornecedor A', dueDate: '2026-11-20', amountCents: 20000, status: 'PENDING', cnpj: '', nfeNumber: '', parcela: '', digitableLine: '', xmlFileName: '', boletoFileName: '' },
  { id: '3', supplier: 'Fornecedor B', dueDate: '2026-11-25', amountCents: 30000, status: 'PENDING', cnpj: '', nfeNumber: '', parcela: '', digitableLine: '', xmlFileName: '', boletoFileName: '' },
  { id: '4', supplier: 'Fornecedor A', dueDate: '2026-11-15', amountCents: 5000, status: 'PENDING', cnpj: '', nfeNumber: '', parcela: '', digitableLine: '', xmlFileName: '', boletoFileName: '' }
];
sandbox.state.groupBy = 'SUPPLIER';
sandbox.state.sortField = 'dueDate';
const groupedBySupplier = sandbox.getFilteredAndSortedRecords(new Map());
const seenSuppliers = new Set();
let prevSup = null;
for (const r of groupedBySupplier) {
  if (r.supplier !== prevSup) {
    assert.equal(seenSuppliers.has(r.supplier), false, `Cabeçalho repetido para ${r.supplier}`);
    seenSuppliers.add(r.supplier);
    prevSup = r.supplier;
  }
}
console.log('PASS [3/5] Agrupamento por fornecedor sem cabeçalhos repetidos');

// ---------------------------------------------------------
// 4. TESTE DE CLASSIFICAÇÃO DE DATA INVÁLIDA (SEM NaN)
// ---------------------------------------------------------
for (const badDate of ['', '2026-02-30', 'data-invalida', null]) {
  const u = sandbox.classifyRecordUrgency({ dueDate: badDate, status: 'PENDING' });
  assert.equal(u.code, 'INVALID_DATE');
  assert.equal(u.label.includes('NaN'), false);
  assert.equal(u.shortBadge.includes('NaN'), false);
}
console.log('PASS [4/5] Classificação de data inválida sem "NaN dias"');

// ---------------------------------------------------------
// 5. TESTE DO FLUXO ELECTRON (main.js setWindowOpenHandler)
// ---------------------------------------------------------
const openedExternal = [];
const fakeWin = {
  loadFile() {},
  webContents: {
    handler: null,
    setWindowOpenHandler(fn) { this.handler = fn; }
  }
};
const electronMock = {
  app: { whenReady: () => ({ then: (cb) => cb() }), on() {}, quit() {} },
  BrowserWindow: class { constructor() { return fakeWin; } static getAllWindows() { return [fakeWin]; } },
  shell: { openExternal(url) { openedExternal.push(url); } }
};
const mainSandbox = {
  require: (mod) => mod === 'electron' ? electronMock : path,
  __dirname: rootDir,
  URL
};
vm.runInNewContext(mainJs, mainSandbox);
assert.equal(typeof fakeWin.webContents.handler, 'function');

assert.equal(fakeWin.webContents.handler({ url: 'https://www.itau.com.br/' }).action, 'deny');
assert.equal(fakeWin.webContents.handler({ url: 'about:blank' }).action, 'deny');
assert.equal(fakeWin.webContents.handler({ url: 'blob:null/1234' }).action, 'deny');
assert.equal(fakeWin.webContents.handler({ url: 'http://inseguro.local/' }).action, 'deny');
assert.deepEqual(openedExternal, ['https://www.itau.com.br/']);
console.log('PASS [5/5] Fluxo Electron main.js (somente https: encaminhado para shell.openExternal)');
