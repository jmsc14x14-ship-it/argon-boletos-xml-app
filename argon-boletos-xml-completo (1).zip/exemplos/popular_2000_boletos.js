// Cole no Console do DevTools (F12) com o Argon aberto para popular 2.000 boletos de teste
// e medir o tempo de renderAll com console.time('renderAll_2000')
(() => {
  const suppliers = [
    'Kalunga Comércio Ltda', 'Kabum Eletrônicos S.A.', 'Atacadão S.A.',
    'CPFL Paulista Energia', 'Dell Computadores Ltda', 'Totvs S.A.',
    'Pichau Informática Ltda', 'Distribuidora Brasil Sul', 'Mercantil Ribeirão',
    'Logística Paulista S.A.', 'Vivo Empresas Telecom', 'Claro Corporativo'
  ];
  const generated = [];
  for (let i = 0; i < 2000; i++) {
    const dayOffset = (i % 40) - 5;
    const d = new Date(Date.UTC(2026, 10, 17 + dayOffset)).toISOString().slice(0, 10);
    generated.push({
      id: 'bench-' + i,
      supplier: suppliers[i % suppliers.length] + ' #' + (i % 25),
      cnpj: '43.283.811/0001-50',
      nfeNumber: String(100000 + i),
      parcela: '01/01',
      issueDate: '2026-10-20',
      dueDate: d,
      amountCents: 10000 + (i * 137) % 950000,
      status: i % 5 === 0 ? 'PAID' : 'PENDING',
      xmlKey: i % 2 === 0 ? ('xml-key-' + i) : '',
      boletoKey: '',
      xmlFileName: i % 2 === 0 ? ('nfe_' + i + '.xml') : '',
      boletoFileName: 'boleto_' + i + '.pdf',
      bank: '341-7 | Itaú Unibanco',
      digitableLine: '34191.79001 01043.510047 91020.150008 8 99040000248050',
      category: 'Teste 2000'
    });
  }
  localStorage.setItem('argon_boletos_xml_state_v1', JSON.stringify(generated));
  console.log('2.000 boletos gravados em localStorage. Recarregue a página e rode: console.time("renderAll"); renderAll(); console.timeEnd("renderAll");');
})();
